package catalogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoLibreriaSsddApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoLibreriaSsddApplication.class, args);
	}
}
